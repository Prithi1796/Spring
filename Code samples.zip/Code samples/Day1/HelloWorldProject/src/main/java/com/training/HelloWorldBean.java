package com.training;

public class HelloWorldBean {
	private String name;
	
	public HelloWorldBean() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
