package com.training;

public class XYZCarDealer implements CarDealer{
	
	private CarCompany myCarcompany;
	
	
	
	public XYZCarDealer(){
		
		
	}
	
	
	
	public void deliverCar(){
		
		myCarcompany.deliverCar();
		
	}



	public CarCompany getMyCarcompany() {
		return myCarcompany;
	}



	public void setMyCarcompany(CarCompany myCarcompany) {
		this.myCarcompany = myCarcompany;
	}
	

}
