package com.training;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class AutowireDemo {
	
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
 
		// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
 
		CarDealer carDealer = (CarDealer) context.getBean("carDealer");
		
		carDealer.deliverCar();
	}
	
	
	
	
	
	
	
	
	

}
