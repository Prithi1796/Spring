package com.training;

public class Hyundai implements CarCompany{
	
	public void deliverCar(){
		
		System.out.println("Car delivered by Hyundai");
	}
	

}
