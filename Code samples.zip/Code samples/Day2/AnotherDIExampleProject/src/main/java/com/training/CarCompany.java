package com.training;

public interface CarCompany {

	public void deliverCar();
	
}
