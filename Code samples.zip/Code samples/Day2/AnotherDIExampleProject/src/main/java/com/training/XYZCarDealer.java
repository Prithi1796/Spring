package com.training;

public class XYZCarDealer implements CarDealer{
	
	private CarCompany carCompany;
	
	
	public XYZCarDealer(){
		
		carCompany = new Maruti();
	}
	
	
	public void deliverCar(){
		
		carCompany.deliverCar();
		
	}
	

}
