package com.training;

public interface CarDealer {
	
	public void deliverCar();

}
