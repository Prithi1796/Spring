package com.training;

public class Counter {
	
	int count;
	
	public void incrementCounter(){
		//System.out.println(count);
		
		++count;
		System.out.println("Count value "+ count );
	}

}
