package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

 
public class Hello {
 
	@SuppressWarnings("resource")
	public static void main(String[] args) {
 
		// loading the definitions from the given XML file
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
 
				
		//example for bean scope:singleton and prototype
		Counter counter1 = (Counter)context.getBean("myCounter");
		counter1.incrementCounter();
		
		Counter counter2 = (Counter)context.getBean("myCounter");
		counter2.incrementCounter();
		
		Counter counter3 = (Counter)context.getBean("myCounter");
		counter3.incrementCounter();
		
		
		
		
	}
}