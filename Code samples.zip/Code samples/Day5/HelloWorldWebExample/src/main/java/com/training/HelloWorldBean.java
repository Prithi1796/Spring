package com.training;

public class HelloWorldBean {
	
	private String message = "Hello from bean day2";

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
